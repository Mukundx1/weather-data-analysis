# Data — Daily Weather Observations (Bureau of Meteorology)

One CSV per station per month, exactly as the Bureau of Meteorology publishes
them (a short preamble, then the daily table). Students read these directly;
they do not download anything.

Provenance: the Bureau's Daily Weather Observations (DWO) product,
`https://www.bom.gov.au/climate/dwo/`. Each file name is `IDCJDW<code>.<YYYYMM>.csv`.
The script `../fetch-bom.R` records which stations and months were pulled, and
re-running it refreshes or extends the set. Files are latin1-encoded (the degree
signs in the header), missing observations are blank, and a calm wind is written
as `Calm`.

## Stations in this set

| Code       | Station                         | Months |
|------------|---------------------------------|--------|
| IDCJDW2124 | Sydney (Observatory Hill / Airport / Fort Denison) | 14 (Jul 2025 – Aug 2026) |
| IDCJDW3050 | Melbourne (Olympic Park / Airport) | 14 (Jul 2025 – Aug 2026) |
| IDCJDW8014 | Darwin Airport                  | 14 (Jul 2025 – Aug 2026) |
| IDCJDW7021 | Hobart (Ellerslie Road / Airport) | 1 (Aug 2025) |

Three full-year stations (a humid-temperate coast, a cooler south, and a
tropical north) plus one Hobart month — enough for a clear seasonal signal,
leave-one-station-out validation, and a realistic `Location` factor. Run
`fetch-bom.R` to add the remaining capital cities (Canberra, Brisbane, Adelaide,
Perth) and to bring Hobart up to the full fourteen months before release.
